
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';

// Registro do Service Worker para habilitar o "Modo APK" (Instalação PWA)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(
      (registration) => console.log('BDR SMART SW registered: ', registration),
      (err) => console.log('BDR SMART SW registration failed: ', err)
    );
  });
}

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}
