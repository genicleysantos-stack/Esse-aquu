
import React, { useState, useEffect, useRef } from 'react';
import { 
  Package, MapPin, Send, MessageSquare, Plus, User, 
  Bell, ClipboardList, Activity, 
  Home, X, Wrench, ChevronRight,
  BarChart3, Zap, DollarSign, LogOut,
  Phone, ChevronLeft, Sparkles, Trophy, Cpu, 
  FileSearch, Search, LayoutDashboard,
  Eye, EyeOff, TrendingUp, Clock3,
  Smartphone as SmartphoneIcon, Download, FileCode
} from 'lucide-react';
import { Order, OrderStatus, Message } from './types';
import { getLogisticsAdvice } from './services/geminiService';

const SUPPORT_PHONE = '5527998070773';
const WHATSAPP_LINK = `https://wa.me/${SUPPORT_PHONE}`;

type BDRNotification = {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning';
};

type QuoteRequest = {
  id: string;
  name: string;
  phone: string;
  device: string;
  problem: string;
  status: 'PENDING' | 'ANALYZED' | 'FINISHED';
  timestamp: Date;
};

const LogoComponent: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const scale = size === 'sm' ? 'scale-[0.5]' : size === 'lg' ? 'scale-125' : 'scale-100';
  return (
    <div className={`flex flex-col items-center justify-center leading-none select-none ${scale}`}>
      <div className="flex items-center gap-2">
        <span className="text-[#87ff00] font-[900] text-3xl tracking-tighter italic">BDR</span>
        <div className="flex items-center gap-1">
          <div className="relative w-8 h-8 flex items-center justify-center">
            <Wrench className="text-[#87ff00] w-6 h-6 absolute rotate-45" />
            <Wrench className="text-[#87ff00] w-6 h-6 absolute -rotate-45" />
          </div>
          <SmartphoneIcon className="text-white w-6 h-6 fill-white" />
        </div>
      </div>
      <span className="text-white font-[900] text-3xl tracking-widest mt-[-4px]">SMART</span>
    </div>
  );
};

const LuckyWheel: React.FC<{ onWin: (amount: number, code: string) => void }> = ({ onWin }) => {
  const [rotation, setRotation] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [hasWon, setHasWon] = useState(false);
  const [wheelUsed, setWheelUsed] = useState(() => localStorage.getItem('bdr_wheel_used') === 'true');
  const [wonAmount, setWonAmount] = useState<number | null>(() => {
    const val = localStorage.getItem('bdr_won_amount');
    return val ? parseInt(val) : null;
  });
  const [winningCode, setWinningCode] = useState<string>(() => localStorage.getItem('bdr_win_code') || '');

  const prizes = [5, 10, 50, 15, 20, 30, 5, 25]; 
  const colors = ["#111", "#87ff00", "#111", "#87ff00", "#111", "#87ff00", "#111", "#87ff00"];

  const handleSpinClick = () => {
    if (isSpinning || wheelUsed) return;
    const newPrizeNumber = Math.floor(Math.random() * prizes.length);
    const extraDegrees = (360 / prizes.length) * newPrizeNumber;
    const totalRotation = rotation + (360 * 10) + (360 - (extraDegrees % 360));
    setRotation(totalRotation);
    setIsSpinning(true);
    setTimeout(() => {
      const amount = prizes[newPrizeNumber];
      const code = `BDR${amount}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
      setIsSpinning(false);
      setHasWon(true);
      setWheelUsed(true);
      setWonAmount(amount);
      setWinningCode(code);
      localStorage.setItem('bdr_wheel_used', 'true');
      localStorage.setItem('bdr_won_amount', amount.toString());
      localStorage.setItem('bdr_win_code', code);
      onWin(amount, code);
    }, 4000);
  };

  return (
    <div className="bg-[#111] border border-white/5 rounded-[2.5rem] p-6 flex flex-col items-center gap-6 overflow-hidden relative shadow-2xl">
      <div className="text-center">
        <h3 className="text-sm font-black uppercase italic leading-none flex items-center justify-center gap-2">
          <Sparkles className="w-4 h-4 text-[#87ff00]" /> {wheelUsed ? 'Seu Cupom BDR' : 'Roleta de Descontos'}
        </h3>
        <p className="text-[9px] text-white/40 font-black uppercase tracking-widest mt-1">
          {wheelUsed ? 'Código salvo em seu dispositivo' : 'Gire e ganhe até R$ 50,00 off'}
        </p>
      </div>
      <div className="relative w-48 h-48">
        <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-20">
          <div className="w-4 h-6 bg-white rounded-full shadow-lg flex items-center justify-center">
            <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-black mt-2"></div>
          </div>
        </div>
        <div className={`w-full h-full rounded-full border-4 border-white/10 relative transition-transform duration-[4000ms] ease-in-out ${wheelUsed && !isSpinning ? 'grayscale opacity-20' : ''}`} style={{ transform: `rotate(${rotation}deg)` }}>
          {prizes.map((prize, i) => (
            <div key={i} className="absolute top-0 left-0 w-full h-full" style={{ transform: `rotate(${(360 / prizes.length) * i}deg)`, clipPath: 'polygon(50% 50%, 50% 0%, 100% 0%, 100% 25%)' }}>
              <div className="w-full h-full" style={{ backgroundColor: colors[i], transform: `rotate(${360 / (prizes.length * 2)}deg)` }}></div>
            </div>
          ))}
          {prizes.map((prize, i) => (
            <div key={`text-${i}`} className="absolute top-0 left-0 w-full h-full flex justify-center pt-4" style={{ transform: `rotate(${(360 / prizes.length) * i + (360 / (prizes.length * 2))}deg)` }}>
              <span className={`text-[10px] font-black italic ${colors[i] === '#87ff00' ? 'text-black' : 'text-[#87ff00]'}`}>R${prize}</span>
            </div>
          ))}
          <div className="absolute inset-0 m-auto w-12 h-12 bg-black border-4 border-white/10 rounded-full flex items-center justify-center z-10 shadow-2xl">
            <div className="w-2 h-2 bg-[#87ff00] rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
      <button onClick={handleSpinClick} disabled={isSpinning || wheelUsed} className={`w-full py-4 rounded-2xl font-black uppercase italic text-xs transition-all ${wheelUsed ? 'bg-white/5 text-white/20 cursor-not-allowed' : 'bg-[#87ff00] text-black shadow-[0_10px_30px_rgba(135,255,0,0.3)] active:scale-95'}`}>
        {isSpinning ? 'Sorteando...' : wheelUsed ? 'Giro Único Realizado' : 'Girar Agora'}
      </button>
      {hasWon && wonAmount && (
        <div className="fixed inset-0 z-[500] bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center text-center p-8 animate-in fade-in zoom-in duration-500">
          <Trophy className="w-12 h-12 text-[#87ff00] mb-6 animate-bounce" />
          <h4 className="text-3xl font-[900] italic uppercase text-white">VOCÊ GANHOU!</h4>
          <p className="text-5xl font-[900] text-[#87ff00] mt-4 italic mb-2 tracking-tighter">R$ {wonAmount},00 OFF</p>
          <div className="w-full max-w-xs mt-8 p-6 bg-white/5 rounded-[2rem] border-2 border-dashed border-[#87ff00]/30">
            <p className="text-[10px] font-black text-[#87ff00] uppercase mb-2">CÓDIGO: {winningCode}</p>
            <p className="text-[13px] font-black text-white uppercase italic">Tire um <span className="text-[#87ff00] underline">PRINT</span> agora!</p>
          </div>
          <button onClick={() => setHasWon(false)} className="mt-12 bg-white text-black px-12 py-4 rounded-2xl font-black text-xs uppercase italic">Confirmado!</button>
        </div>
      )}
    </div>
  );
};

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [isLogged, setIsLogged] = useState(false);
  const [view, setView] = useState<'customer' | 'driver' | 'admin'>('customer');
  const [activeTab, setActiveTab] = useState<'home' | 'orders' | 'profile' | 'quotes'>('home');
  const [adminTab, setAdminTab] = useState<'overview' | 'orders' | 'tools'>('overview');
  const [orders, setOrders] = useState<Order[]>([]);
  const [quotes, setQuotes] = useState<QuoteRequest[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isQuoteFormOpen, setIsQuoteFormOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [notifications, setNotifications] = useState<BDRNotification[]>([]);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'model', text: 'Olá! Sou o BDR BOT. Como posso ajudar com seu reparo hoje?', timestamp: new Date() }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [adminPin, setAdminPin] = useState('');
  const [driverPin, setDriverPin] = useState('');
  const [showAdminPin, setShowAdminPin] = useState(false);
  const [showDriverPin, setShowDriverPin] = useState(false);
  const [newOrder, setNewOrder] = useState({ name: '', phone: '', origin: '', destination: '', brand: '', model: '', desc: '' });
  const [newQuote, setNewQuote] = useState({ name: '', phone: '', device: '', problem: '' });

  useEffect(() => {
    const handlePopState = () => {
      setIsFormOpen(false);
      setIsQuoteFormOpen(false);
      setIsChatOpen(false);
    };
    window.addEventListener('popstate', handlePopState);
    const timer = setTimeout(() => setShowSplash(false), 2500);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  useEffect(() => {
    if (chatEndRef.current) chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const addNotification = (title: string, message: string, type: 'info' | 'success' | 'warning' = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [{ id, title, message, type }, ...prev]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 4000);
  };

  const handleLogin = (role: 'customer' | 'driver' | 'admin') => {
    if (role === 'admin' && adminPin !== '710512') return addNotification('Erro', 'PIN Administrativo incorreto', 'warning');
    if (role === 'driver' && driverPin !== 'coleta') return addNotification('Erro', 'Senha incorreta', 'warning');
    setView(role);
    setIsLogged(true);
    addNotification('Acesso Autorizado', `Perfil ${role.toUpperCase()} conectado`, 'success');
  };

  const openOverlay = (setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    setter(true);
    window.history.pushState({ modal: true }, "");
  };

  const closeOverlay = (setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    setter(false);
    if (window.history.state?.modal) window.history.back();
  };

  const exportSourceCode = () => {
    const sourceContent = `
--- BDR SMART LOGISTICS - SOURCE CODE BACKUP ---
DATA: ${new Date().toLocaleString()}

--- FILE: manifest.json ---
{
  "name": "BDR SMART Logistics",
  "short_name": "BDR SMART",
  "display": "standalone",
  "background_color": "#000000",
  "theme_color": "#87ff00"
}

--- FILE: sw.js ---
// Service Worker for PWA Offline support
const CACHE_NAME = 'bdr-smart-v1';
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE_NAME)));

--- FILE: index.html ---
// PWA enabled with standalone display mode.

--- NOTA ---
Este projeto foi gerado com React 19 e Tailwind CSS.
Suporte: (27) 99807-0773
    `;
    const blob = new Blob([sourceContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'bdr_smart_source.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addNotification('Sucesso', 'Código fonte exportado!', 'success');
  };

  const handleCreateQuote = () => {
    if(!newQuote.name || !newQuote.phone || !newQuote.device || !newQuote.problem) return addNotification('Atenção', 'Todos os campos são obrigatórios.', 'warning');
    const quote: QuoteRequest = {
      id: `Q-${Math.floor(1000 + Math.random() * 9000)}`,
      ...newQuote,
      status: 'PENDING',
      timestamp: new Date()
    };
    setQuotes(prev => [quote, ...prev]);
    addNotification('Sucesso', 'Solicitação enviada!', 'success');
    setNewQuote({ name: '', phone: '', device: '', problem: '' });
  };

  const handleCreateOrder = () => {
    if(!newOrder.name || !newOrder.phone || !newOrder.origin || !newOrder.brand) return addNotification('Atenção', 'Preencha os dados da coleta.', 'warning');
    const order: Order = {
      id: `BDR-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: newOrder.name,
      customerPhone: newOrder.phone,
      origin: newOrder.origin,
      destination: newOrder.destination || 'BDR Central',
      deviceBrand: newOrder.brand,
      deviceModel: newOrder.model,
      serviceDescription: newOrder.desc,
      status: OrderStatus.PENDING,
      createdAt: new Date(),
      estimatedCost: 35.00
    };
    setOrders(prev => [order, ...prev]);
    closeOverlay(setIsFormOpen);
    addNotification('Sucesso', 'Chamado aberto!', 'success');
  };

  const updateOrderStatus = (id: string, newStatus: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === id ? {...o, status: newStatus} : o));
    addNotification('Status Atualizado', `${id} -> ${newStatus}`, 'info');
  };

  const handleSendMessage = async () => {
    if(!chatInput.trim()) return;
    const msg = chatInput;
    setChatInput('');
    setMessages(prev => [...prev, {id: Date.now().toString(), role:'user', text: msg, timestamp: new Date()}]);
    setIsTyping(true);
    const response = await getLogisticsAdvice(msg);
    setMessages(prev => [...prev, {id: (Date.now() + 1).toString(), role:'model', text: response, timestamp: new Date()}]);
    setIsTyping(false);
  };

  if (showSplash) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-[100]">
        <LogoComponent size="lg" />
        <div className="absolute bottom-12 flex flex-col items-center">
          <div className="w-8 h-1 bg-[#87ff00]/20 rounded-full overflow-hidden mb-2">
            <div className="h-full bg-[#87ff00] w-1/2 animate-[loading_1.5s_infinite_ease-in-out]"></div>
          </div>
          <p className="text-[#87ff00] text-[10px] font-black uppercase tracking-[0.3em]">Inicializando BDR SMART...</p>
        </div>
        <style>{` @keyframes loading { 0% { transform: translateX(-100%); } 100% { transform: translateX(200%); } } `}</style>
      </div>
    );
  }

  if (!isLogged) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col p-8 z-[150] overflow-y-auto">
        <div className="mt-12 mb-16"><LogoComponent size="lg" /></div>
        <div className="space-y-6 flex-1">
          <h2 className="text-3xl font-black italic uppercase">Sua Operação <br/><span className="text-[#87ff00]">Smart</span></h2>
          <div className="space-y-4">
            <button onClick={() => handleLogin('customer')} className="w-full bg-[#111] border border-white/5 p-6 rounded-[2rem] flex items-center justify-between group active:scale-95 transition-all shadow-xl">
              <div className="flex items-center gap-4">
                <div className="bg-[#87ff00] p-3 rounded-2xl text-black"><User className="w-6 h-6" /></div>
                <p className="font-black italic uppercase text-white">Cliente BDR</p>
              </div>
              <ChevronRight className="w-5 h-5 text-white/20" />
            </button>
            <div className="bg-[#111] border border-white/5 p-6 rounded-[2rem] space-y-4">
              <div className="relative">
                <input type={showDriverPin ? "text" : "password"} placeholder="SENHA MOTORISTA" className="w-full bg-transparent border-b border-white/10 pb-4 outline-none text-xs font-black uppercase text-white placeholder:text-white/10" value={driverPin} onChange={e => setDriverPin(e.target.value)} />
                <button onClick={() => setShowDriverPin(!showDriverPin)} className="absolute right-0 top-0 text-white/20">{showDriverPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
              </div>
              <button onClick={() => handleLogin('driver')} className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase italic text-xs active:scale-95">Entrar Motorista</button>
            </div>
            <div className="bg-[#111] border border-white/5 p-6 rounded-[2rem] space-y-4">
              <div className="relative">
                <input type={showAdminPin ? "text" : "password"} placeholder="PIN ADMINISTRADOR" className="w-full bg-transparent border-b border-white/10 pb-4 outline-none text-xs font-black uppercase text-[#87ff00] placeholder:text-white/10" value={adminPin} onChange={e => setAdminPin(e.target.value)} />
                <button onClick={() => setShowAdminPin(!showAdminPin)} className="absolute right-0 top-0 text-white/20">{showAdminPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
              </div>
              <button onClick={() => handleLogin('admin')} className="w-full bg-[#87ff00] text-black py-4 rounded-2xl font-black uppercase italic text-xs shadow-lg active:scale-95">Painel Master</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-black text-white overflow-hidden relative font-sans">
      <div className="fixed top-14 left-0 right-0 z-[200] px-4 pointer-events-none flex flex-col gap-2">
        {notifications.map(n => (
          <div key={n.id} className="pointer-events-auto bg-[#111]/95 backdrop-blur-md border-l-4 border-[#87ff00] rounded-2xl p-4 shadow-2xl">
            <div className="flex items-start gap-3">
              <Bell className="w-4 h-4 text-[#87ff00]" />
              <div><h4 className="text-[10px] font-black uppercase text-[#87ff00]">{n.title}</h4><p className="text-xs font-medium text-white/80">{n.message}</p></div>
            </div>
          </div>
        ))}
      </div>

      <header className="px-5 pt-12 pb-4 flex items-center justify-between border-b border-white/10 shrink-0 bg-black/50 backdrop-blur-xl sticky top-0 z-40">
        <div className="flex items-center">
          {view === 'admin' ? (
             <button onClick={() => setIsLogged(false)} className="p-2 -ml-2 text-white/20 flex items-center gap-2"><LogOut className="w-5 h-5" /><span className="text-[10px] font-black uppercase italic">Sair Admin</span></button>
          ) : activeTab !== 'home' ? (
            <button onClick={() => setActiveTab('home')} className="p-2 -ml-2 text-[#87ff00]"><ChevronLeft className="w-6 h-6" /></button>
          ) : (
            <div className="scale-75 -ml-6"><LogoComponent size="sm" /></div>
          )}
        </div>
        <div className="flex items-center gap-2">
          {view !== 'admin' && (
            <>
              <button onClick={() => openOverlay(setIsChatOpen)} className="p-3 bg-white/5 rounded-2xl text-[#87ff00]"><MessageSquare className="w-5 h-5" /></button>
              <button onClick={() => setActiveTab('profile')} className={`p-3 rounded-2xl ${activeTab === 'profile' ? 'bg-[#87ff00] text-black' : 'bg-white/5 text-white'}`}><User className="w-5 h-5" /></button>
            </>
          )}
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-48">
        {view === 'admin' ? (
          <div className="p-5 space-y-6">
            <div className="flex items-center gap-4 overflow-x-auto no-scrollbar">
              <button onClick={() => setAdminTab('overview')} className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase italic ${adminTab === 'overview' ? 'bg-[#87ff00] text-black' : 'bg-white/5 text-white/40'}`}>Dashboard</button>
              <button onClick={() => setAdminTab('orders')} className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase italic ${adminTab === 'orders' ? 'bg-[#87ff00] text-black' : 'bg-white/5 text-white/40'}`}>Entregas</button>
              <button onClick={() => setAdminTab('tools')} className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase italic ${adminTab === 'tools' ? 'bg-[#87ff00] text-black' : 'bg-white/5 text-white/40'}`}>Ferramentas</button>
            </div>
            {adminTab === 'overview' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#111] p-6 rounded-[2.5rem] border border-white/5">
                  <Zap className="w-5 h-5 text-[#87ff00] mb-4" />
                  <p className="text-[9px] font-black text-white/40 uppercase">Ganhos Mês</p>
                  <p className="text-2xl font-black italic">R$ 4.280</p>
                </div>
                <div className="bg-[#111] p-6 rounded-[2.5rem] border border-white/5">
                  <Clock3 className="w-5 h-5 text-[#87ff00] mb-4" />
                  <p className="text-[9px] font-black text-white/40 uppercase">Chamados</p>
                  <p className="text-2xl font-black italic">{orders.length}</p>
                </div>
              </div>
            )}
            {adminTab === 'orders' && (
              <div className="space-y-4">
                {orders.map(o => (
                  <div key={o.id} className="bg-[#111] p-6 rounded-[2.5rem] border border-white/5">
                    <p className="text-[10px] font-black uppercase text-[#87ff00] mb-2">{o.customerName}</p>
                    <p className="text-xs italic mb-4">{o.deviceBrand} {o.deviceModel}</p>
                    <div className="grid grid-cols-2 gap-2">
                       <button onClick={() => updateOrderStatus(o.id, OrderStatus.IN_TRANSIT)} className="bg-white/5 py-3 rounded-2xl text-[8px] font-black uppercase italic">Em Rota</button>
                       <button onClick={() => updateOrderStatus(o.id, OrderStatus.DELIVERED)} className="bg-[#87ff00] text-black py-3 rounded-2xl text-[8px] font-black uppercase italic">Finalizar</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {adminTab === 'tools' && (
              <div className="space-y-4">
                <div className="bg-[#111] p-8 rounded-[3rem] border border-white/5">
                  <FileCode className="w-10 h-10 text-[#87ff00] mb-6" />
                  <h4 className="text-xl font-black uppercase italic mb-2">Exportar Projeto</h4>
                  <p className="text-[11px] text-white/40 font-medium leading-relaxed mb-6 uppercase">Baixe todos os arquivos do sistema estruturados para salvar em seu computador.</p>
                  <button onClick={exportSourceCode} className="w-full bg-[#87ff00] text-black py-6 rounded-3xl font-black uppercase italic flex items-center justify-center gap-3">
                    <Download className="w-5 h-5" /> Baixar Código (.txt)
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : activeTab === 'profile' ? (
          <div className="p-5 space-y-6">
            <div className="bg-[#111] p-10 rounded-[3rem] border border-white/5 flex flex-col items-center text-center">
              <div className="w-24 h-24 bg-[#87ff00] rounded-full flex items-center justify-center mb-6"><User className="w-12 h-12 text-black" /></div>
              <h2 className="text-2xl font-black italic uppercase text-[#87ff00]">BDR SMART</h2>
              <p className="text-[10px] text-white/20 font-black uppercase tracking-widest mt-2">ID: {Math.floor(1000 + Math.random() * 9000)}</p>
            </div>
            <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="w-full bg-[#25D366] p-8 rounded-[3rem] flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-6"><Phone className="w-8 h-8 fill-white" /><div><h4 className="text-sm font-black uppercase text-white">Suporte Técnico</h4><p className="text-[10px] text-white/60 font-black mt-2">(27) 99807-0773</p></div></div>
              <ChevronRight className="w-5 h-5 text-white/40" />
            </a>
            <button onClick={() => setIsLogged(false)} className="w-full bg-red-500/10 p-6 rounded-3xl border border-red-500/20 text-red-500 font-black uppercase italic text-xs">Sair do App</button>
          </div>
        ) : activeTab === 'orders' ? (
          <div className="p-5 space-y-6">
            <h3 className="text-xl font-black uppercase italic">Minhas <span className="text-[#87ff00]">Entregas</span></h3>
            {orders.length === 0 ? (
              <div className="text-center py-20 bg-[#111] rounded-[3rem] border border-white/5"><p className="text-[11px] text-white/20 uppercase font-black">Nenhuma coleta ativa no momento.</p></div>
            ) : (
              <div className="space-y-4">
                {orders.map(o => (
                  <div key={o.id} className="bg-[#111] p-8 rounded-[3rem] border border-white/5 shadow-xl">
                    <span className="text-[9px] font-black uppercase px-3 py-1.5 rounded-full bg-[#87ff00] text-black mb-4 inline-block">{o.status}</span>
                    <h4 className="text-xl font-black uppercase italic">{o.deviceBrand} {o.deviceModel}</h4>
                    <p className="text-[11px] text-white/30 uppercase mt-4 flex items-center gap-2"><MapPin className="w-4 h-4 text-[#87ff00]" /> {o.origin.substring(0, 30)}...</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : activeTab === 'quotes' ? (
          <div className="p-5 space-y-6">
            <h3 className="text-xl font-black uppercase italic">Solicitar <span className="text-[#87ff00]">Orçamento</span></h3>
            <div className="bg-[#111] p-8 rounded-[3rem] border border-white/5 space-y-4">
              <input type="text" placeholder="SEU NOME COMPLETO" className="w-full bg-black/50 border border-white/10 p-5 rounded-2xl text-xs font-black uppercase text-white outline-none" value={newQuote.name} onChange={e => setNewQuote({...newQuote, name: e.target.value})} />
              <input type="text" placeholder="WHATSAPP PARA RETORNO" className="w-full bg-black/50 border border-white/10 p-5 rounded-2xl text-xs font-black uppercase text-white outline-none" value={newQuote.phone} onChange={e => setNewQuote({...newQuote, phone: e.target.value})} />
              <input type="text" placeholder="APARELHO (MARCA/MODELO)" className="w-full bg-black/50 border border-white/10 p-5 rounded-2xl text-xs font-black uppercase text-white outline-none" value={newQuote.device} onChange={e => setNewQuote({...newQuote, device: e.target.value})} />
              <textarea placeholder="DESCREVA O PROBLEMA" rows={3} className="w-full bg-black/50 border border-white/10 p-5 rounded-2xl text-xs font-black uppercase text-white outline-none resize-none" value={newQuote.problem} onChange={e => setNewQuote({...newQuote, problem: e.target.value})} />
              <button onClick={handleCreateQuote} className="w-full bg-[#87ff00] text-black py-5 rounded-2xl font-black uppercase italic">Enviar via BDR</button>
            </div>
            {quotes.map(q => (
              <div key={q.id} className="bg-[#111] p-6 rounded-[2.5rem] border border-white/5"><p className="text-[10px] font-black text-[#87ff00]">{q.id}</p><p className="text-xs italic uppercase">{q.device}</p></div>
            ))}
          </div>
        ) : (
          <div className="p-5 space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => openOverlay(setIsFormOpen)} className="bg-gradient-to-br from-[#111] to-black rounded-[3rem] p-8 border border-white/5 shadow-2xl flex flex-col justify-between aspect-square active:scale-95 group">
                <Zap className="w-8 h-8 text-[#87ff00]" />
                <h2 className="text-xl font-black uppercase italic leading-tight">LEVA E <br/><span className="text-[#87ff00]">TRAZ</span></h2>
              </button>
              <button onClick={() => setActiveTab('quotes')} className="bg-[#111] rounded-[3rem] p-8 border border-white/5 flex flex-col justify-between aspect-square active:scale-95">
                <FileSearch className="w-8 h-8 text-white/20" />
                <h2 className="text-xl font-black uppercase italic leading-tight">ORÇAR <br/><span className="text-white/40">REPARO</span></h2>
              </button>
            </div>
            <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="w-full bg-[#111] p-8 rounded-[3rem] border border-white/5 flex items-center justify-between active:scale-95">
              <div className="flex items-center gap-6"><div className="bg-[#25D366] p-4 rounded-3xl"><Phone className="w-6 h-6 text-white fill-white" /></div><h4 className="text-sm font-black uppercase italic">WHATSAPP DIRETO</h4></div>
              <ChevronRight className="w-5 h-5 text-white/10" />
            </a>
            <LuckyWheel onWin={(amt) => addNotification('PARABÉNS!', `Desconto de R$ ${amt},00 liberado!`, 'success')} />
          </div>
        )}
      </main>

      {isFormOpen && (
        <div className="fixed inset-0 z-[600] flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/95" onClick={() => closeOverlay(setIsFormOpen)}></div>
          <div className="relative bg-[#0a0a0a] rounded-t-[4rem] p-10 pb-16 border-t border-white/10 max-h-[90vh] overflow-y-auto">
            <div className="w-16 h-1 bg-white/10 rounded-full mx-auto mb-8"></div>
            <h3 className="text-3xl font-black uppercase italic text-[#87ff00] mb-8">Coleta Smart</h3>
            <div className="space-y-4">
              <input type="text" placeholder="SEU NOME" className="w-full bg-white/5 border border-white/5 p-6 rounded-3xl text-[11px] font-black uppercase text-white outline-none" value={newOrder.name} onChange={e => setNewOrder({...newOrder, name: e.target.value})} />
              <input type="text" placeholder="WHATSAPP" className="w-full bg-white/5 border border-white/5 p-6 rounded-3xl text-[11px] font-black uppercase text-white outline-none" value={newOrder.phone} onChange={e => setNewOrder({...newOrder, phone: e.target.value})} />
              <input type="text" placeholder="ENDEREÇO DE COLETA" className="w-full bg-white/5 border border-white/5 p-6 rounded-3xl text-[11px] font-black uppercase text-white outline-none" value={newOrder.origin} onChange={e => setNewOrder({...newOrder, origin: e.target.value})} />
              <div className="grid grid-cols-2 gap-4">
                <input type="text" placeholder="MARCA" className="w-full bg-white/5 border border-white/5 p-6 rounded-3xl text-[11px] font-black uppercase text-white outline-none" value={newOrder.brand} onChange={e => setNewOrder({...newOrder, brand: e.target.value})} />
                <input type="text" placeholder="MODELO" className="w-full bg-white/5 border border-white/5 p-6 rounded-3xl text-[11px] font-black uppercase text-white outline-none" value={newOrder.model} onChange={e => setNewOrder({...newOrder, model: e.target.value})} />
              </div>
              <button onClick={handleCreateOrder} className="w-full bg-[#87ff00] text-black py-6 rounded-3xl font-black uppercase italic shadow-lg mt-6">Solicitar Motoboy</button>
            </div>
          </div>
        </div>
      )}

      {isChatOpen && (
        <div className="fixed inset-0 z-[1000] bg-black flex flex-col">
           <header className="px-6 pt-14 pb-8 border-b border-white/5 flex items-center gap-5 bg-black/80 backdrop-blur-3xl sticky top-0">
              <button onClick={() => closeOverlay(setIsChatOpen)} className="p-3 bg-white/5 rounded-2xl text-[#87ff00]"><ChevronLeft className="w-6 h-6" /></button>
              <div><h4 className="text-md font-black uppercase italic text-white">BDR BOT</h4><p className="text-[9px] text-[#87ff00] font-black uppercase mt-1 tracking-widest animate-pulse">Online</p></div>
           </header>
           <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {messages.map(m => (
                <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-[85%] p-5 rounded-[2rem] text-[11px] leading-relaxed ${m.role === 'user' ? 'bg-[#87ff00] text-black rounded-tr-none' : 'bg-[#111] text-white rounded-tl-none border border-white/10'}`}>{m.text}</div>
                </div>
              ))}
              {isTyping && <div className="bg-[#111] p-4 rounded-3xl w-fit text-[#87ff00] text-[10px] font-black italic">BDR está digitando...</div>}
              <div ref={chatEndRef} />
           </div>
           <div className="p-6 border-t border-white/5 bg-black pb-12">
              <div className="bg-[#111] border border-white/10 rounded-[2rem] p-3 flex items-center gap-3">
                 <input type="text" placeholder="PERGUNTE AO BDR BOT..." className="flex-1 bg-transparent border-0 outline-none px-4 text-[11px] font-black uppercase text-white placeholder:text-white/10" value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} />
                 <button onClick={handleSendMessage} className="bg-[#87ff00] text-black p-5 rounded-[1.5rem]"><Send className="w-5 h-5" /></button>
              </div>
           </div>
        </div>
      )}

      {view === 'customer' && (
        <nav className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-3xl border-t border-white/5 px-8 pt-6 pb-12 flex items-center justify-between z-50">
          <NavButton active={activeTab === 'home'} icon={<Home className="w-5 h-5" />} label="Home" onClick={() => setActiveTab('home')} />
          <NavButton active={activeTab === 'orders'} icon={<ClipboardList className="w-5 h-5" />} label="Status" onClick={() => setActiveTab('orders')} />
          <button onClick={() => openOverlay(setIsFormOpen)} className="bg-[#87ff00] text-black p-5 rounded-full shadow-lg -mt-16 border-[6px] border-black hover:scale-110 active:scale-90 transition-all"><Plus className="w-7 h-7 stroke-[4px]" /></button>
          <NavButton active={activeTab === 'quotes'} icon={<FileSearch className="w-5 h-5" />} label="Orçar" onClick={() => setActiveTab('quotes')} />
          <NavButton active={activeTab === 'profile'} icon={<User className="w-5 h-5" />} label="Perfil" onClick={() => setActiveTab('profile')} />
        </nav>
      )}
    </div>
  );
};

const NavButton: React.FC<{ active: boolean; icon: React.ReactNode; label: string; onClick: () => void }> = ({ active, icon, label, onClick }) => (
  <button onClick={onClick} className={`flex flex-col items-center gap-1.5 ${active ? 'text-[#87ff00]' : 'text-white/20'}`}>
    {icon}<span className="text-[8px] font-black uppercase italic tracking-widest">{label}</span>
  </button>
);

export default App;
